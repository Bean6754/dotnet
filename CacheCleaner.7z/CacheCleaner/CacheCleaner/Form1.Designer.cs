﻿namespace CacheCleaner
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_chromium = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_chromium
            // 
            this.button_chromium.Location = new System.Drawing.Point(12, 12);
            this.button_chromium.Name = "button_chromium";
            this.button_chromium.Size = new System.Drawing.Size(113, 23);
            this.button_chromium.TabIndex = 0;
            this.button_chromium.Text = "Chromium/Google Chrome";
            this.button_chromium.UseVisualStyleBackColor = true;
            this.button_chromium.Click += new System.EventHandler(this.button_chromium_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_chromium);
            this.Name = "Form1";
            this.Text = "Cache Cleaner";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_chromium;
    }
}

