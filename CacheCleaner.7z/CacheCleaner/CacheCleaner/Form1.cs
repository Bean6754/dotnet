﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CacheCleaner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_chromium_Click(object sender, EventArgs e)
        {
            Process[] pname_chromium = Process.GetProcessesByName("chromium");
            Process[] pname_chrome = Process.GetProcessesByName("chrome");
            if (pname_chromium.Length == 0 || pname_chrome.Length == 0)
            {
                // Process is running.
                DialogResult dialogResult = MessageBox.Show("Chromium/Google Chrome is still running." + '\n' + "Do you want me to close Chromium/Google Chrome?" + '\n' + "This is needed for me to remove the cache files.", "Application Still Running", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    // Kill processes.
                    try
                    {
                        foreach (Process proc_chromium in Process.GetProcessesByName("chromium"))
                        {
                            proc_chromium.Kill();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    try
                    {
                        foreach (Process proc_chrome in Process.GetProcessesByName("chrome"))
                        {
                            proc_chrome.Kill();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    // Exit.
                    Application.Exit();
                }
            }
            else
            {
                // Continue.
            }

            // Variables.
            string localappdata = Environment.GetEnvironmentVariable("localappdata");
            string dir_cache = localappdata + "//Google//Chrome//User Data//Default//Cache";
            string dir_codecache = localappdata + "//Google//Chrome//User Data//Default//Code Cache";

            // Check if directory exists.
            if (System.IO.Directory.Exists(dir_cache))
            {
                //MessageBox.Show("Directory exists.");
                // Delete all files inside of this directory.
                try
                {
                    string[] files_dir_cache = System.IO.Directory.GetFiles(dir_cache);
                    foreach (string file in files_dir_cache)
                    {
                        System.IO.File.SetAttributes(file, System.IO.FileAttributes.Normal);
                        System.IO.File.Delete(file);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (!System.IO.Directory.Exists(dir_cache))
            {
                //MessageBox.Show("Directory does not exist.");
                // Leave deletion alone.
            }
            else
            {
                MessageBox.Show("Error 1: Could not check if directory %localappdata%\\Google\\Chrome\\User Data\\Default\\Cache exists.");
            }

            if (System.IO.Directory.Exists(dir_codecache))
            {
                //MessageBox.Show("Directory exists.");
                // Delete all files inside of this directory.
                try {
                    string[] files_dir_codecache = System.IO.Directory.GetFiles(dir_codecache);
                    foreach (string file in files_dir_codecache)
                    {
                        System.IO.File.SetAttributes(file, System.IO.FileAttributes.Normal);
                        System.IO.File.Delete(file);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (!System.IO.Directory.Exists(dir_codecache))
            {
                //MessageBox.Show("Directory does not exist.");
                // Leave directory alone.
            }
            else
            {
                MessageBox.Show("Error 1: Could not check if directory %localappdata%\\Google\\Chrome\\User Data\\Default\\Code Cache exists.");
            }
        }
    }
}
